from distutils.core import setup

setup(
        name='Machine-learning-analysis',
        version='',
        packages=['tests', 'resources', 'learning_logic', 'console_interface'],
        url='',
        license='',
        author='Agustin',
        author_email='',
        description=''
)


